﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa11_01
{
    // 52 - Estructuras
    internal class Program
    {
        // definición
        public struct empleado 
        {
            public string nombre;
            public int edad;
            public int id;
            public double sueldo;
        }
        static void Main(string[] args)
        {
            // creación de una variable de tipo empleado
            empleado uno;

            // asignación de valores
            uno.nombre = "Juan";
            uno.edad = 28;
            uno.id = 567;
            uno.sueldo = 10500.50;

            // Impresión de valores
            Console.WriteLine(uno.nombre);
            Console.WriteLine(uno.edad);
            Console.WriteLine(uno.id);  
            Console.WriteLine(uno.sueldo);
        }
    }
}
