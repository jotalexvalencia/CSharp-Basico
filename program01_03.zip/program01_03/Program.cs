﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program01_03
{
    internal class Program
    {
        // 54- Arreglos de estructuras 
        public struct empleado 
        {
            public string nombre;
            public int edad;
            public int id;
            public double sueldo;

            public override string ToString()
            {
                StringBuilder cadena = new StringBuilder();
                cadena.AppendFormat("Empleado: {0}, Nombre: {1} \r\nEdad: {2}, Sueldo: {3}",id,nombre,edad,sueldo);
                return cadena.ToString();
            }
        }
        static void Main(string[] args)
        {
            // Variables
            int n = 0;
            empleado[] gente = new empleado[3];
            string dato = "";

            // Pedimos la información
            for(n=0; n<3; n++) 
            { 
                Console.WriteLine("Dame el id");
                dato = Console.ReadLine();
                gente[n].id = Convert.ToInt32(dato);

                Console.WriteLine("Dame el nombre");               
                gente[n].nombre = Console.ReadLine();

                Console.WriteLine("Dame la edad");
                dato = Console.ReadLine();
                gente[n].edad = Convert.ToInt32(dato);

                Console.WriteLine("Dame el sueldo");
                dato = Console.ReadLine();
                gente[n].sueldo = Convert.ToDouble(dato);
            }
            // mostramos la información
            for(n=0; n < 3; n++) 
            {
                Console.WriteLine(gente[n]);
                Console.WriteLine("----------");
            }

            for(n= 0; n < 3; n++) 
            { 
                if(gente[n].sueldo<2000000)
                    Console.WriteLine("Aumento para {0}",gente[n].nombre);
            }
        }
    }
}
