﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tips002
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Este programa hacer uso de los argumentos de línea de comando
            // Obtiene un nombre por línea de comando y la cantidad de veces indicada

            // variables
            string nombre = "";
            int repeticiones = 0;
            int n = 0;

            // Verificamos que se tenga la cantidad de argumentos
            if (args.Length != 2)
            {
                Console.WriteLine("Debe poner el nombre y las repeticiones");
            }
            else 
            { 
                // obtenemos los argumentos
                nombre = args[0];
                repeticiones = Convert.ToInt32(args[1]);

                // hacemos el saludo
                for (n = 0; n < repeticiones; n++)
                    Console.WriteLine("Hola {0}!",nombre);
                {

                }
            }

        }
    }
}
