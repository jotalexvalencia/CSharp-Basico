﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa10_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 46 - Métodos que solo realizan trabajo

            // Variables
            string dato = default(string);
            int opcion = default(int);
            double a = default(double);
            double b = default(double);
            double r = default(double);

            // presentamos menú
            do 
            {
                Console.WriteLine("1-Suma, 2-Resta, 3-Multi, 4-Div, 5-Salir");
                dato = Console.ReadLine();
                opcion = Convert.ToInt32(dato);

                if (opcion == 1) 
                    Suma();
                if (opcion == 2) 
                {
                    Console.WriteLine("Dame el primer valor");
                    dato = Console.ReadLine();
                    a = Convert.ToDouble(dato);

                    Console.WriteLine("Dame el segundo valor");
                    dato = Console.ReadLine();
                    b = Convert.ToDouble(dato);

                    resta(a, b);
                }
                if (opcion == 3) 
                {
                    r = multi();
                    Console.WriteLine("El resultado de la multiplicación es {0}", r);
                }
                if (opcion == 4) 
                {
                    Console.WriteLine("Dame el primer valor");
                    dato = Console.ReadLine();
                    a = Convert.ToDouble(dato);

                    Console.WriteLine("Dame el segundo valor");
                    dato = Console.ReadLine();
                    b = Convert.ToDouble(dato);

                    r = div(a, b);
                    Console.WriteLine("El resultado de la división es {0}", r);

                }
            } while (opcion != 5);


        }

        // método que solo ejecuta código
        public static void Suma() 
        {
            double x = 0;
            double y = 0;
            double resul = 0;
            string valor = "";

            Console.WriteLine("Dame el primer valor");
            valor = Console.ReadLine();
            x = Convert.ToDouble(valor);

            Console.WriteLine("Dame  el segundo valor");
            valor = Console.ReadLine();
            y = Convert.ToDouble(valor);

            resul = x + y;

            Console.WriteLine("El resultado de la suma es {0}", resul);
        }

        // 47 método que recibe valores
        public static void resta(double x, double y) 
        {
            double result = 0;

            result = x - y;

            Console.WriteLine("El resultado de la resta es {0}", result);
        }

        // 48 - Métodos que regresan valores
        public static double multi() 
        {
            double x = 0;
            double y = 0;
            double resultado = 0;
            string valor = default(string);

            Console.WriteLine("Dame el primer valor");
            valor = Console.ReadLine();
            x = Convert.ToDouble(valor);

            Console.WriteLine("Dame el segundo valor");
            valor = Console.ReadLine();
            y = Convert.ToDouble(valor);

            resultado = x * y;

            return resultado;

        }

        // 50 - Métodos que reciben parámetros y regresan valor
        public static double div(double x, double y) 
        {
            double resultado = default(double);

            resultado = x / y;

            return resultado;
        }

    }
}
