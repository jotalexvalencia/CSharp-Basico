﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace program11_02
{
    internal class Program
    {
        // 53 - Impresión de estructuras
        public struct empleado 
        {
            public string nombre;
            public int edad;
            public int id;
            public double sueldo;

            public override string ToString()
            {
                StringBuilder cadena = new StringBuilder();
                cadena.AppendFormat("Empleado: {0}, Nombre: {1} \r\nEdad: {2}, Sueldo: {3}", id, nombre, edad, sueldo);
                return cadena.ToString();
            }
        }
        static void Main(string[] args)
        {
            // creación de una variable del tipo empleado
            empleado uno;

            // asignación de valores
            uno.nombre = "Alex";
            uno.edad = 47;
            uno.id = 29;
            uno.sueldo = 2000000;

            // impresión de valores
            Console.WriteLine(uno);
            Console.WriteLine("------------------------------------------------------");
            Console.WriteLine(uno.edad.ToString());
        }
    }
}
