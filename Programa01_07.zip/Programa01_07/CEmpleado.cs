﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Programa01_07
{
    internal class CEmpleado
    {
        private double sueldo;
        private double impuesto;
        public void Muestra()
        {
            Console.WriteLine("Suledo={0}, impuesto={1}", Sueldo, Impuesto);
        }

        public double Sueldo 
        {
            get
            { 
                return sueldo;
            } 

            set 
            { 
                sueldo = value;
            }
        }

        public double Impuesto 
        { get 
            { 
                return impuesto;
            } 
        } 

        // Mutator
        public void CalculaImpuesto()
        {
            impuesto = sueldo * 0.16;
        }
    }
}
