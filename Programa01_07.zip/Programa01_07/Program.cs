﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Programa01_07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Creamos objeto
            CEmpleado Juan = new CEmpleado();

            Juan.Sueldo = 15000;
            Juan.CalculaImpuesto();

            Console.WriteLine("El impuesto de Juan es {0}", Juan.Impuesto);

            Juan.Muestra();
        }
    }
}
