﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa03_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Saludos
            Console.WriteLine("Hola a todos");

            // Conteo
            Console.WriteLine("1");
            Console.WriteLine("Dos");

            // Despedida
            Console.WriteLine("Adios");

            // Uso de Write
            Console.Write("Texto de");
            Console.WriteLine(" prueba");
        }
    }
}
