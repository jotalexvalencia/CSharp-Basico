﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa01_08
{
    internal class CCalculadora
    {
        public int Suma (int a, int b)
        { return a + b; }

        public double Suma(double a, double b)
        { return a + b; }
    }
}
