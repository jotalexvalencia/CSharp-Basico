﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa01_08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int rInt = default(int);
            double rDouble = default(double);

            CCalculadora calculadora = new CCalculadora();

            rInt = calculadora.Suma(7 , 2);
            Console.WriteLine("Suma enteros: {0} ", rInt);

            rDouble = calculadora.Suma(7.5 , 2.7);
            Console.WriteLine("Suma de dobles: {0}", rDouble);
        }
    }
}
