﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa10_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 51 - Ejercicio resuelto
            // Hacer un programa que calcule el costo de construir una casa
            // El programa pedirá la cantidad de habitaciones y las dimensiones de cada una
            // el costo por m2 de habitación es de $300 con impuesto de 5%
            // el costo por m2 de cocina y sanitario es de $375 con impuesto de 12%
            // el costo por m2 de jardin es de $120 con impuesto del 0%

            // datos
            int n = 0;
            int numHab = 0;
            int tipo = 0;// 1- habitacion, 2- cocina, 3- jardin
            double grantotal = 0.0;
            string dato = "";
            double area = 0.0;
            double costoHab = 0.0;

            // Pedir el número de habitaciones
            Console.WriteLine("Cuántos elementos hay en tu casa");
            dato = Console.ReadLine();
            numHab = Convert.ToInt32(dato);

            for (n = 0; n < numHab; n++)
            {
                // calcular área
                area = calcularArea();
                // pedir el tipo de habitación
                Console.WriteLine("Qué tipo es?1- habitación, 2- cocina, 3-jardin");
                dato = Console.ReadLine();
                tipo = Convert.ToInt32(dato);
                // calcular costo
                if (tipo == 1)
                    costoHab = calcularCosto(area, 300.0, 0.05);
                if (tipo == 2)
                    costoHab = calcularCosto(area, 375.0, 0.12);
                if (tipo == 3)
                    costoHab = calcularCosto(area, 120.0, 0.0);
                // sumar el gran total
                grantotal += costoHab;
            }
            // presentar resultado
            Console.WriteLine("El costo total es de  {0}", grantotal);
        }
        // método para calcular áreas
        public static double calcularArea() 
        {
            double area = default(double);
            double ancho = default(double);
            double largo = default(double);
            string dato = default(string);

            Console.WriteLine("Dame el ancho de la habitación");
            dato = Console.ReadLine();
            ancho = Convert.ToDouble(dato);

            Console.WriteLine("Dame el largo de la habitación");
            dato = Console.ReadLine();
            largo = Convert.ToDouble(dato);

            area = ancho * largo;

            return area;
        }
        // método para calcular el costo
        public static double calcularCosto(double area, double pM2, double impuesto)
        {
            double costo = 0.0;
            double imp = 0.0;
            double total = 0.0;
            
            costo = area * pM2;
            imp = costo * imp;
            total = costo + imp;

            return total;
        }
    }
}
