﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa07_15
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // programa que conviete el peso en la tierra al peso en Mercurio, Venus o Marte

            // Variables
            int opcion = default(int);
            double pesoTierra = default(double);
            double pesoPlaneta = default(double);

            // pedir el planeta
            Console.WriteLine("1. Mercurio, 2. Venus, 3. Marte");
            opcion = Convert.ToInt32(Console.ReadLine());

            // pedir el peso en la tierra
            Console.WriteLine("Dame tu peso en la tierra");
            pesoTierra = Convert.ToInt32(Console.ReadLine());


            // verificar en que planeta fue
            switch (opcion)
            {
                // caso Mercurio
                case 1:
                    pesoPlaneta = pesoTierra * 0.38;
                    break;
                // caso Venus
                case 2:
                    pesoPlaneta = pesoTierra * 0.91;
                    break;
                // caso Marte
                case 3:
                    pesoPlaneta = pesoTierra * 0.38;
                    break;

            }
            // Mostrar el peso convertido
            Console.WriteLine("Tu peso en ese planeta es {0}", pesoPlaneta);
        }
    }
}
