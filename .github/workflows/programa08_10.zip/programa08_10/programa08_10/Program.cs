﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa08_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 39 - Ciclos anidados

            // este programa muestra los números primos del 1 al 100

            // variables
            int n = 0;
            int m = 0;
            bool primo = true;

            for (n = 2; n < 100; n++)
            {
                primo = true;
                for (m = 2; m < n; m++)
                {
                    if (n % m == 0)
                        primo = false;


                }

                if (primo == true)
                    Console.WriteLine("{0}", n);

            }

            Console.WriteLine();
        }
    }
}
