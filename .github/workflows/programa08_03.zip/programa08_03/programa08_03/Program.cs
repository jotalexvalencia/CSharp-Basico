﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa08_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // este programa muestra un contador y un acumulador
            int n = 0;
            int contador = 0;
            int acumulador = 0;
            int valor = 0;
            string dato = "";

            // ejemplo de contador
            //for (n = 0; n < 10; n++)
            //{
            //    Console.WriteLine("En el ciclo");
            //    contador = contador + 1;
            //}

            //Console.WriteLine("El contador tiene {0}", contador);

            // ejemplo de acumulador
            // el operador ++ adiciona uno a la variable
            // n = n+1 es igual a n++
            for (n = 0; n < 5; n++)
            {
                Console.WriteLine("Dame un número");
                dato = Console.ReadLine();
                valor = Convert.ToInt32(dato);

                acumulador = acumulador + valor;
            }

            Console.WriteLine("El acumulado es {0}", acumulador);

        }
    }
}
