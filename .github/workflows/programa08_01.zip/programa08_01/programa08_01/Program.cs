﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa08_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // programa que muestra el for de forma básica
            int n = 0;

            for (n = 0; n < 5; n++)
            {
                Console.WriteLine("Hola");
            }
        }
    }
}
