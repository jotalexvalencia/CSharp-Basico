﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa06_02
{
    internal class Program
    {
        static void Main(string[] args)
        { 
            // variables
            string dato = default(string);

            // pedir nombre
            Console.WriteLine("Dame tu nombre");
            dato = Console.ReadLine();

            // pedir apellido
            dato = dato + " ";
            Console.WriteLine("Dame tu apellido");
            dato += Console.ReadLine();

            // madar mensaje
            Console.WriteLine("Hola {0}", dato);
        }
    }
}
