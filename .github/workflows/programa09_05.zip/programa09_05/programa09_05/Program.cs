﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa09_05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 42 - Arreglos, Matrices

            // programa que muestra el uso de arreglos en dos dimesiones o matrices

            // variables
            int n = 0; // para las filas
            int m = 0; // para las columnas
            double sumatoria = 0;
            double promedio = 0.0;
            Random rnd = new Random();

            int[,] datos = new int[4, 7]; // filas 4, columnas 7

            // llenamos los datos
            for (n = 0; n < 4; n++)
            {
                for (m = 0; m < 7; m++)
                {
                    datos[n, m] = rnd.Next(30);
                }
            }

            // Imprimimos los datos
            for(n=0; n<4;n++)
            {
                Console.WriteLine("Semana {0}", n);
                for (m = 0; m < 7; m++) 
                {
                    Console.Write("{0},", datos[n, m]);
                }
                Console.WriteLine();
            }

            // calculamos el promedio por semana
            for (n = 0; n < datos.GetLength(0); n++)
            {
                sumatoria = 0.0;
                promedio = 0.0;

                for (m=0;m< datos.GetLength(1); m++)
                {
                    sumatoria += datos[n, m];
                }
                promedio = sumatoria / 7.0;
                Console.WriteLine("El promedio de la semana {0} es {1}", n, promedio);

            }

            // calculamos el promedio total
            sumatoria = 0.0;
            promedio = 0.0;
            for (n = 0; n < 4; n++)
            {
                for (m = 0; m < 7; m++)
                {
                    sumatoria += datos[n, m];
                }
            }
            promedio = sumatoria / 28.0;
            Console.WriteLine("El promedio total es {0}", promedio);
        }
    }
}
