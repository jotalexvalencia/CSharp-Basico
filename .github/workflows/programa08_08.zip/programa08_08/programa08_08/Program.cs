﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa08_08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 37 - Ciclo While
            // programa que muestra el ciclo while
            // puede no llevarse a cabo ni una vez
            // se usa cuando no sabemos el número de repeticiones

            // variables
            int dinero = 0;
            int opcion = 0;
            string dato = "";
            int total = 0;

            // Pedimos la cantidad de dinero
            Console.WriteLine("Cuánto dinero tienes");
            dato = Console.ReadLine();
            dinero = Convert.ToInt32(dato);

            while (dinero > 0 && opcion != 5)
            {
                // Presentamos menú
                Console.WriteLine("1. Dulces, 2. Papas, 3. Chocolates, 4. Helado, 5. Salir");
                dato = Console.ReadLine();
                opcion = Convert.ToInt32(dato);

                switch (opcion)
                {
                    case 1:
                        dinero -= 3;
                        total += 3;
                        break;
                    case 2:
                        dinero -= 12;
                        total += 12;
                        break;
                    case 3:
                        dinero -= 7;
                        total += 7;
                        break;
                    case 4:
                        dinero -= 25;
                        total += 25;
                        break;

                }

                Console.WriteLine("Tienes {0} y has gastado {1}", dinero, total);


            } // fin del while

            Console.WriteLine("Adios");

        }
    }
}
