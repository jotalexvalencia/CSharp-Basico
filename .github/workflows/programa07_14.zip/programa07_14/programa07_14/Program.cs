﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa07_14
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // programa que convierte de millas a km o de km a millas

            // variables
            int opcion = default(int);
            double km = default(double);
            double millas = default(double);
            string dato = default(string);

            // presentar un menú
            Console.WriteLine("1. Millas a Km, 2. Km a millas");
            dato = Console.ReadLine();
            opcion = Convert.ToInt32(dato);

            // si es de millas a km
            if (opcion == 1)
            {
                // pedir la cantidad de millas
                Console.WriteLine("Dame las Millas");
                dato = Console.ReadLine();
                millas = Convert.ToDouble(dato);

                if (millas < 0)
                {
                    Console.WriteLine("Dar un número positivo");
                }
                else
                {
                    // converrir a km
                    km = millas * 1.609;

                    // mostrar los km
                    Console.WriteLine("{0} millas son {1} km", millas, km);
                }

            }

            // si es de km a millas
            if (opcion == 2)
            {
                // pedir la cantidad de km
                Console.WriteLine("Dame los km");
                dato = Console.ReadLine();
                km = Convert.ToDouble(dato);

                if (millas >= 0)
                {
                    // convertir a millas
                    millas = km / 1.609;

                    // mostrar las millas
                    Console.WriteLine("{0} km son {1} millas", km, millas);
                }
            }

        }
    }
}
