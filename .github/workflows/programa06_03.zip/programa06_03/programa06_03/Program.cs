﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa06_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Varibles
            string dato = default(string);
            int valor = default(int);
            double valorpf = default(double);   

            // Pedir un número
            Console.WriteLine("Dame un número");
            dato = Console.ReadLine();
            valor = Convert.ToInt32(dato);
            //valor = int.Parse(dato); // otra forma

            // Mostrar
            Console.WriteLine("El número es {0}", valor);

            // pedir valor de punto flotante
            Console.WriteLine("Dame un número de punto flotante");
            dato = Console.ReadLine();
            //valorpf = Convert.ToDouble(dato); // otra forma
            valorpf = Double.Parse(dato);

            // mostrar el valor
            Console.WriteLine("El valor de pf es {0}", valorpf);
        }
    }
}
