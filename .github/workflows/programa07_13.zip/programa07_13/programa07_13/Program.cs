﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa07_13
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // realizar la suma, resta, multiplicación o división de dos números, según lo desee el usuario

            // variables
            string dato = default(string);
            double numero1 = default(double);
            double numero2 = default(double);
            int seleccion = default(int);
            double resultado = default(double);

            // pedir número 1
            Console.WriteLine("Dame el número 1");
            dato = Console.ReadLine();
            numero1 = Convert.ToDouble(dato);

            // pedir número 2
            Console.WriteLine("Dame el número 2");
            dato = Console.ReadLine();
            numero2 = Convert.ToDouble(dato);

            // pedir operación
            Console.WriteLine("1. suma, 2. resta, 3. multiplicación, 4. división");
            Console.WriteLine("Qué operación deseas?");
            dato = Console.ReadLine();
            seleccion = Convert.ToInt32(dato);

            switch (seleccion) 
            {
                // Determinar si es suma
                case 1:
                    resultado = numero1 + numero2;
                    break;

                // Determinar si es resta
                case 2:
                    resultado = numero1 - numero2;
                    break;

                // Determinar si es multiplicación
                case 3:
                    resultado = numero1 * numero2;
                    break;

                // Determinar si es división
                case 4:
                    resultado = numero1 / numero2;
                    break;
                // mostrar el resultado
                default:
                    Console.WriteLine("Su selección es inválida");
                    break;

            }

            Console.WriteLine("El resultado es {0}", resultado);


        }
    }
}
