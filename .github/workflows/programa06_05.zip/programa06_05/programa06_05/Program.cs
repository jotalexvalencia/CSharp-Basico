﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa06_05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Convierta de pesos a dólares

            // Variables
            string dato = "";
            double cantPesos = 0.0;
            double tasaCambio = 0.0;
            double cantDolares = 0.0;

            // Pedir la cantidad de pesos
            Console.WriteLine("Dame la cantidad de pesos");
            dato = Console.ReadLine();
            cantPesos = Convert.ToDouble(dato);

            // Pedir la tasa de cambio
            Console.WriteLine("Un dólar cuántos pesos son");
            dato = Console.ReadLine();
            tasaCambio = Convert.ToDouble(dato);

            // Hacer la conversión
            cantDolares = cantPesos / tasaCambio;

            // Mostrar resultados
            Console.WriteLine("{0} pesos son {1} dólares", cantPesos, cantDolares);


        }
    }
}
