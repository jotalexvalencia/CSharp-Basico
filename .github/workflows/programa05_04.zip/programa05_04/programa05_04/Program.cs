﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa05_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Convertir de C a F

            // Variables
            double C = 38.3;
            double F = default(double);

            // Convertir
            F = C * 1.8 + 32;
            // Mostrar resultado
            Console.WriteLine("{0} C son {1} F",C,F);


        }
    }
}
