﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa07_10
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // NOT - ! - NO
            // Es verdadero cuando el valor es falso
            // A | R
            // F | V
            // V | F

            // Este programa imprime la suma, solo si el primer número NO es menor a 10

            // Variables

            int a = default(int);   
            int b = default(int);   
            int suma = default(int);
            string dato = default(string);

            // Pedimos los números

            Console.WriteLine("Dame el primer número");
            dato = Console.ReadLine();
            a = Convert.ToInt32(dato);

            Console.WriteLine("Dame el segundo número");
            dato = Console.ReadLine();
            b = Convert.ToInt32(dato);

            // verificamos que no sea menor que 10
            if (!(a < 10))
            {
                // hacemos la suma
                suma = a + b;

                // mostramos el resultado
                Console.WriteLine("La suma es {0}", suma);
            }
            else 
            {
                Console.WriteLine("El primer número es menor que 10");
            }


        }
    }
}
