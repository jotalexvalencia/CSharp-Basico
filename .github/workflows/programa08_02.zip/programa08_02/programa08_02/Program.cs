﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa08_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // programa que calcula el promedio de cualquier cantidad de números

            // variables
            int cantidad = 0;
            int n = 0;
            double sumatoria = 0.0;
            double valor = 0.0;
            double promedio = 0.0;
            string dato = "";

            // pedimos la cantidad de números
            Console.WriteLine("Cuántos números van a ser");
            dato = Console.ReadLine();
            cantidad = Convert.ToInt32(dato);

            // n++ -> n=n+1
            for (n = 0; n < cantidad; n++) 
            {
                Console.WriteLine("Dame el número");
                dato = Console.ReadLine();
                valor = Convert.ToDouble(dato);

                // sumatoria = sumatoria + valor; es igual a
                // sumatoria += valor;

                sumatoria += valor;
            }

            promedio = sumatoria / cantidad;

            Console.WriteLine("El promedio es {0}", promedio);
        }
    }
}
