﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa07_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Estructuras selectivas
            // if(expresión) sentencia;
            //operadores relacionales ==, >, <, >=, <=, !=

            int a = 5, b = 8, c=5;

            if (a == c)
                Console.WriteLine("a={0} y c={1} son iguales", a, c);

            if (b > c)
                Console.WriteLine("b={0} es mayor que c={1}", b, c);

            if (a < b)
                Console.WriteLine("a={0} es menor que b={1}", a, b);

            if (b >= c)
                Console.WriteLine("b={0} es mayor o igual que c={1}", b, c);

            if (c <= b)
                Console.WriteLine("c={1} es menor o igal que b={0}", b, c);

            if (a != b)
                Console.WriteLine("a={0} es diferente que b={1}", a, b);
        }
    }
}
