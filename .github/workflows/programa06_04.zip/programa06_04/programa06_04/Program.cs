﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa06_04
{
    internal class Program
    {
        static void Main(string[] args)
        { 
            // Programa que calcule el área y perímetro de un rectángulo

            // Variables
            string dato = "";
            double ladoA = 0.0;
            double ladoB = 0.0;
            double area = 0.0;
            double perimetro = 0.0;

            // pedir el lado a
            Console.WriteLine("Dame el lado menor");
            dato = Console.ReadLine();
            ladoA = Convert.ToDouble(dato);

            // pedir el lado b
            Console.WriteLine("Dame el lado mayor");
            dato = Console.ReadLine();
            ladoB = Convert.ToDouble(dato);

            // calcular el área
            area = ladoA * ladoB;

            // calcular el perímetro
            perimetro = 2 * (ladoA * ladoB);

            // mostrar resultados
            Console.WriteLine("El rectángulo de lados {0}, {1}", ladoA, ladoB);
            Console.WriteLine("Tiene un área de  {0} y un perímetro de {1}", area, perimetro);
        }
    }
}
