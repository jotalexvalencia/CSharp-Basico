﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa07_11
{
    internal class Program
    {
        static void Main(string[] args)
        {

            // realizar la suma, resta, multiplicación o división de dos números, según lo desee el usuario

            // variables            
            double numero1 = default(double);
            double numero2 = default(double);
            int seleccion = 0;
            double resultado = default(double);

            // pedir número 1
            Console.WriteLine("Dame el número 1");
            numero1 = Convert.ToDouble(Console.ReadLine());

            // pedir número 2
            Console.WriteLine("Dame el número 2");
            numero2 = Convert.ToDouble(Console.ReadLine());

            // pedir operación
            Console.WriteLine("1. suma, 2. resta, 3. multiplicación, 4. división");
            Console.WriteLine("Qué operación deseas?";
            seleccion = Convert.ToInt32(Console.ReadLine());

            // determinar si es suma
            if (seleccion == 1)
                resultado = numero1 + numero2;
            else if (seleccion == 2) // determinar si es resta
                resultado = numero1 - numero2;
            else if (seleccion == 3) // determinar si es multiplicación
                resultado = numero1 * numero2;
            else if (seleccion == 4) // determinar si es división
                resultado = numero1 / numero2;
            else
                Console.WriteLine("su selección es inválida");

            // mostramos resultado
            Console.WriteLine("El resultado es {0}", resultado;


        }
    }
}
