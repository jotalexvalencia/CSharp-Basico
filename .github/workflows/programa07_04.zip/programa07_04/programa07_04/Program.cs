﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa07_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Convertir de metgros a pies o de pies a metros, según lo seleccione el usuario

            // Variables
            string dato = default(string);
            int opcion = default(int);
            double metros = default(double);
            double pies = default(double);

            // Pedir la opción
            Console.WriteLine("1. metros a pies, 2. pies a metros");
            Console.WriteLine("Qué opción deseas?");
            dato = Console.ReadLine();
            opcion = Convert.ToInt32(dato);

            // Determinar si es metros a pies
            if (opcion == 1)
            {
                // pedir cantidad de metros
                Console.WriteLine("Dame los metros");
                dato = Console.ReadLine();
                metros = Convert.ToDouble(dato);
                
                // calcular pies
                pies = metros * 3.28;

                // mostrar resultado
                Console.WriteLine("{0} metros son {1} pies", metros, pies);
            }

            // Determinar si es pies a metros
            if (opcion == 2)
            {
                // pedir cantidad de pies
                Console.WriteLine("Dame los pies");
                dato = Console.ReadLine();
                pies = Convert.ToDouble(dato);

                // calcular metros
                metros = pies / 3.28;

                // mostrar resultado
                Console.WriteLine("{0} pies son {1} metros",  pies, metros);
            }
        }
    }
}
