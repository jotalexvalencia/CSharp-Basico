﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa07_09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // OR - || - O
            // Es verdadero si al menos unos es verdadero
            // A B | R
            // F F | F
            // F V | V
            // V F | V
            // V V | V

            // Este programa imprime la suma, si hay un número menor a 10
            // Variables

            int a = default(int);
            int b = default(int);
            int suma = default(int);
            string dato = default(String);

            // Pedimos los números

            Console.WriteLine("Dame el primer número");
            dato = Console.ReadLine();
            a = Convert.ToInt32(dato);

            Console.WriteLine("Dame el segundo número");
            dato = Console.ReadLine();
            b = Convert.ToInt32(dato);

            // verificamos que a sea menor que 10 o b sea menor que 10
            if(a < 10 || b < 10) 
            {
                // hacemos la suma
                suma = a + b;

                // mostramos resultado
                Console.WriteLine("LA suma es {0}", suma);
            }
            else 
            {
                Console.WriteLine("ningún número fue menor que 10");
            }

        }
    }
}
