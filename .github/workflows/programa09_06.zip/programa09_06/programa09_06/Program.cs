﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa09_06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 44- Ejercicios resueltos arreglos

            // variables
            int[] valores = new int[11];
            int numero = default(int);
            string dato = default(string);
            int n = default(int);
            int mayor = default(int);

            for(n=0; n<11;n++)
            {
                Console.WriteLine("Dame un número entre 0 y 10");
                dato = Console.ReadLine();
                numero = Convert.ToInt32(dato);

                valores[numero]++;
            }

            for(n=0;n<11;n++)
            {
                Console.WriteLine("El número {0} apareció {1} veces", n, valores[n]);
               
            }

            for (n = 0; n < 11; n++) 
            {
                if (valores[n] > mayor)
                    mayor = n;
            }

            Console.WriteLine("El número Mayor que se repitió más veces es {0}", mayor);
        }
    }
}
