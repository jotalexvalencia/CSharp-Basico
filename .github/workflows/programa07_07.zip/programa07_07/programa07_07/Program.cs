﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa07_07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // este programa pide datos solo a mayores de 18 años

            // variables

            int edad = default(int);
            int diferencia = default(int);
            string dato = default(string);
            string nombre = default(string);
            string ciudad = default(string);

            // pedimos la edad
            Console.WriteLine("Dame tu edad");
            dato = Console.ReadLine();
            edad = Convert.ToInt32(dato);

            // si es mayor hacemos lo del bloque del if, sino lo del bloque del else
            if (edad >= 18)
            {
                // pedimos los demas datos
                Console.WriteLine("Dame tu nombre");
                nombre = Convert.ToString(Console.ReadLine());

                Console.WriteLine("Dame tu cidudad");
                ciudad = Convert.ToString(Console.ReadLine());

                // mostramos los datos
                Console.WriteLine("datos personales nombre: {0}, ciudad: {1}", nombre, ciudad);
            }
            else 
            {
                Console.WriteLine("No tiene la edad requerida");
            }
        }
    }
}
