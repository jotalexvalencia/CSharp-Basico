﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa07_08
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // AND - && - y
            // Solo es verdadero cuando los dos son verdaderos
            //  A   B   | R
            //  F   F   | F
            //  F   V   | F
            //  V   F   | F
            //  V   V   | V

            // este programa imprime la suma, solo cuando los dos números sena
            // menores a 10

            // variables

            int a = 0;
            int b = 0;
            int suma = 0;
            string dato = "";

            // pedimos los números

            Console.WriteLine("Dame el primer número");
            dato = Console.ReadLine();
            a = Convert.ToInt32(dato);

            Console.WriteLine("Dame el segundo número");
            dato = Console.ReadLine();
            b = Convert.ToInt32(dato);

            // verificamos que ambos números sean menores que 10
            if (a <10 && b < 10) 
            {
                // hacemos la suma
                suma = a + b;

                // mostramos el resultado
                Console.WriteLine("La suma es {0}", suma);
            }
            else 
            {
                Console.WriteLine("Los dos números no son menores a 10");
            }


        }
    }
}
