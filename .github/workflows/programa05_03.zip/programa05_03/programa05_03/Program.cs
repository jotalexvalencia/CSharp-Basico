﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa05_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // operaciones basicas con variables

            // HAcer un programa que calcule el área y perímetro de un cuadrado

            // Variables
            double lado = 5.0;
            double area = default(double);
            double perimetro = default(double);

            // calcular area
            area = lado * lado;

            // calcular perimetro
            perimetro = lado * 4;

            // mostrar resultados
            Console.WriteLine("El área de un cuadrado de lado {0} es {1}",lado,area);
            Console.WriteLine("El perímetro es {0}", perimetro);
            
        }
    }
}
