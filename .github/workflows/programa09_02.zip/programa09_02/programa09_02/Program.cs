﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa09_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 40 Arreglos

            // Variables

            double[] calif = new double[3];

            double promedio = default(double);
            double sumatoria = default(double);
            double diferencia = default(double);
            int n = default(int);
            string dato = default(string);

            // pedimos las calificaciones
            for(n = 0; n < 3; n++) 
            {
                Console.WriteLine("Dame la calificación");
                dato = Console.ReadLine();
                calif[n] = Convert.ToDouble(dato);
            }

            // calculamos el promedio
            for(n=0; n < 3; n++) 
            {
                sumatoria += calif[n];
            }
            promedio = sumatoria / 3;

            // calculamos diferencia e imprimimos
            for (n = 0; n < 3; n++) 
            { 
                diferencia = promedio - calif[n];
                Console.WriteLine("La calificación es {0}, el promedio es {1}, y su diferencia es de {2}", calif[n], promedio, diferencia);
            }
        }
    }
}
