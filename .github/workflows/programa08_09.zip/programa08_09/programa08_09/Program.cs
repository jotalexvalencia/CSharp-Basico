﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa08_09
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 39 - Ciclos anidados

            // variables

            int n = 0;
            int m = 0;
            int producto = 0;

            // Imprime las tablas de multiplicar

            for ( n = 1; n <= 10; n++)
            {
                for (m = 1; m <= 10; m++)
                {
                    producto = n * m;
                    Console.WriteLine("{0} X {1} = {2}", n, m, producto);

                }
                Console.WriteLine();
            }
        }
    }
}
