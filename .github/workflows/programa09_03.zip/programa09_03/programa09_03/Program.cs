﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa09_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 41 - Más sobre arreglos

            // variables

            double[] calif;
           // double[] calif = { 7.5, 8.0, 9.2, 6.7 }; /// incializar el arreglo con valores 

            double promedio = default(double);
            double sumatoria = default(double);
            double diferencia = default(double);
            int n = default(int);
            string dato = default(string);
            int cantidad = default(int);

            // pedimos la cantidad de datos
            Console.WriteLine("Dame la cantidad de calificaciones");
            dato = Console.ReadLine();
            cantidad = Convert.ToInt32(dato);

            calif = new double[cantidad];

            // pedimos las calificaciones
            for (n = 0; n < calif.Length; n++) 
            {
                Console.WriteLine("Dame la calificación");
                dato=Console.ReadLine();
                calif[n] = Convert.ToDouble(dato);
            } 

            // calculamos el promedio
            for (n=0; n < calif.Length; n++) 
            { 
                sumatoria += calif[n];
            } 
            promedio = sumatoria / calif.Length; 

            // calculamos diferencia e imprimimos
            for(n=0; n < calif.Length; n++) 
            {
                diferencia = promedio - calif[n];
                Console.WriteLine("La calificación es {0}, el promedio es {1}, y su diferencia es de {2}", calif[n], promedio, diferencia);
            }
        }
    }
}
