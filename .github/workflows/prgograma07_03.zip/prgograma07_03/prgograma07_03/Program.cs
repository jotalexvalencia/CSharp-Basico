﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace prgograma07_03
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // realizar la suma, resta, multiplicación o div de dos números según lo desee el usuario

            // variables
            double numeroA= default(double), numeroB = default(double), resultado=default(double);
            char operacion = default(char);
            // pedir números 
            Console.WriteLine("Ingrese el primer número");
            numeroA = Convert.ToDouble(Console.ReadLine());

            Console.WriteLine("Ingrese el primer número");
            numeroB = Convert.ToDouble(Console.ReadLine());

            // pedir operación
            Console.WriteLine(@"Ingrese la operación:"+ Environment.NewLine+
            "(s) suma"+ Environment.NewLine+
            "(r) resta"+ Environment.NewLine+
            "(m) multiplicación"+ Environment.NewLine+
            "(d) división");

            // determinar que operación requiere el usuario
            operacion = Convert.ToChar(Console.ReadLine());
            if (operacion.Equals('s')) 
            {
                resultado = numeroA + numeroB;
                Console.WriteLine("La suma de {0} + {1} = {2}",numeroA,numeroB,resultado);
            }
            if (operacion.Equals('d'))
            {
                resultado = numeroA / numeroB;
                Console.WriteLine("La división de {0} / {1} = {2}", numeroA, numeroB, resultado);
            }
            if (operacion.Equals('r'))
            {
                resultado = numeroA - numeroB;
                Console.WriteLine("La resta de {0} - {1} = {2}", numeroA, numeroB, resultado);
            }
            if (operacion.Equals('m'))
            {
                resultado = numeroA * numeroB;
                Console.WriteLine("La multiplicación de {0} x {1} = {2}", numeroA, numeroB, resultado);
            }
        }
    }
}
