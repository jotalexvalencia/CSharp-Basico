﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa05_05
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Calcualr el área total de una casa con tres habitaciones
            // Variables
            double ancho1 = 4.3;
            double largo1 = 4.0;
            double area1 = default(double);

            double ancho2 = 5.0;
            double largo2 = 6.7;
            double area2 = default(double);

            double ancho3 = 2.89;
            double largo3 = 3.54;
            double area3 = default(double);

            double areaTotal = default(double);

            // Calcular área de hab1
            area1 = ancho1 * largo1;

            // Calcular área de hab2
            area2 = ancho2 * largo2;

            // Calcular área de hab3
            area3=ancho3*largo3;

            // Calcular área total
            areaTotal = area1 + area2 + area3;

            // mostrar el resultado
            Console.WriteLine("El área total de la casa es {0}", areaTotal);
        }
    }
}
