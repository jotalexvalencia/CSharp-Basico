﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa10_01Metodo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //  45 - Conceptos básicos de los métodos

            // calcular el promedio de 5 números
            // usamos métodos (funciones)
            // reutilización de código
            // especialización
            // mas fácil mantenimiento y depuración

            // variables
            double num1 = 0;
            double num2 = 0;
            double num3 = 0;
            double num4 = 0;
            double num5 = 0;
            double promedio = 0;

            // pedir numero1
            num1 = Pedir(1);

            // pedir numero2
            num2 = Pedir(2);

            // pedir numero3
            num3 = Pedir(3);

            // pedir numero4
            num4 = Pedir(4);

            // pedir numero5
            num5 = Pedir(5);

            // calcular promedio
            promedio = (num1 + num2 + num3 + num4 + num5) / 5.0;

            // mostrar el promedio
            Console.WriteLine("El promedio es  {0}", promedio);
        }

        // partes del método
        // acceso publico, estatico devuelve double y recibe un int
        public static double Pedir(int n)
        {
            double numero = 0.0;
            string dato = "";
            Console.WriteLine("->Dame el número {0}", n);
            dato = Console.ReadLine();
            numero = Convert.ToDouble(dato);

            return numero;
        }
    }
}
