﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa08_07
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 36 - Ciclo Do While

            // Programa que muestra el uso del ciclo do while
            // se lleva a cabo al menos una vez
            // se usa cuando no sabemos la cantidad de repeticiones

            // variables
            int opcion = 0;
            string dato = "";
            double tipoCambio = 4922.70;
            double pesos = 0.0;
            double dolares = 0.0;

            // Hacemos el ciclo do while
            do
            {
                // Mostramos el menú
                Console.WriteLine("1. Pesos a dólares, 2. Dólares a pesos, 3. Salir");
                dato = Console.ReadLine();
                opcion = Convert.ToInt32(dato);

                if (opcion == 1)
                {
                    // Pedimos los pesos
                    Console.WriteLine("Cuántos pesos");
                    dato = Console.ReadLine();
                    pesos = Convert.ToDouble(dato);

                    // Convertimos
                    dolares = pesos / tipoCambio;
                    Console.WriteLine("Son {0} dólares", dolares);
                }
                else if (opcion == 2)
                {

                    // Pedimos los dolares
                    Console.WriteLine("Cuántos dólares");
                    dato = Console.ReadLine();
                    dolares = Convert.ToDouble(dato);

                    // Convertimos
                    pesos = dolares * tipoCambio;
                    Console.WriteLine("Son {0} pesos", pesos);
                }
            } while (opcion != 3);

            Console.WriteLine("Adios");
        }
    }
}
