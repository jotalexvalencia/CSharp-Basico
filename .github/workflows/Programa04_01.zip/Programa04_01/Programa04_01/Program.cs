﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa04_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // bool - booleanos v o f
            // char - caracteres
            // int - números enteros
            // float - números con punto decimal
            // double - números con punto decimal
            // string - colecciones de caracteres, frases, palabras, etc

            // Declaración - creamos la variable
            // Inicialización - cuando se le da su primer valor
            // Asignación - cuando se le da un valor

            // Declaración -> tipo nombre;
            int valor;

            // Inicialización nombre = valor;
            valor = 5;

            Console.WriteLine("Valor de inicio es {0}",valor);

            // Asignación nombre = nuevo valor;
            valor = 7;

            Console.WriteLine("El valor de {0} es colocado en la variable",valor);

        }
    }
}
