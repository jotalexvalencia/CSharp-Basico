﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace programa07_06
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Este programa dice si un número es par o impar

            // variables

            int numero = default(int);
            string dato = default(string);

            // pedimos el número
            Console.WriteLine("Dame un número entero");
            dato = Console.ReadLine();
            numero = Convert.ToInt32(dato);

            // Si es para hace esto y sino lo que esta en el else
            if (numero % 2 == 0)
                Console.WriteLine("El número es par");
            else
                Console.WriteLine("El número es impar");
        }
    }
}
