﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tips001
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Este programa muesra como podemos usar switch con otros tipos
            // aparte de int

            // variables

            bool booleana  = false;
            char caracter = 'x';
            string cadena = "Priviet";

            // Con bool
            //switch (booleana)
            //{
            //    case true:
            //        Console.WriteLine("La variable tiene true");
            //        break;
            //    case false:
            //        Console.WriteLine("La variable tiene false");
            //        break;

            //}
            // Con caracter
            //switch (caracter)
            //{
            //    case 'a':
            //    case 'e':
            //    case 'i':
            //    case 'o':
            //    case 'u':
            //        Console.WriteLine("Es vocal");
            //        break;
            //    default:
            //        Console.WriteLine("Es consonante");
            //        break;
            //}
            // Con cadena
            switch (cadena)
            {
                case "Hola":
                    Console.WriteLine("Español");
                    break;
                case "Hello":
                    Console.WriteLine("Inglés");
                    break;
                case "Priviet":
                    Console.WriteLine("Ruso");
                    break;
            }
        }
    }
}
