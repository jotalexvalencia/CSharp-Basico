﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program01_02
{
    internal class CMiClase
    {
        // Estos datos se pueden ver en cualquier lugar de la clase
        // pero no fuera de ella, ámbito objeto
        private int b = 10;

        public void Muestra()
        {
            // Creamos una variable locla a Muestra
            // Ámbito local
            int m = 5;
            int b = 3;
            // Podemos usar la variable local
            Console.WriteLine("m={0}",m);

            // Tratamos de mostrar la variable de main
            // No se puede
            // Console.WriteLine("a={0}", a);

            // Tratamos de mostrar el dato de la clase
            Console.WriteLine("ámbito local b={0}", b);
            Console.WriteLine("ámbito objeto this.b={0}", this.b);
        }

        public void Multiplicador()
        {
            // Tratamos de usar el dato de la clase
            b = b * 5;

            // Tratamos de usar la variable local del otro método
            // No se puede
            //m = m * 100;

        }
    }
}
