﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Program01_02
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Esta variable solo se conoce en main
            int a = 5;

            a = a * 5;
            Console.WriteLine("a={0}",a);

            // Tratamos de usar directamente el dato de la clase
            // No se puede
            // b = 30;
            //Console.WriteLine("b={0}", b);

            // Instanciamos ahora
            CMiClase objeto = new CMiClase();

            objeto.Muestra();
            objeto.Multiplicador();
            objeto.Muestra();
        }
    }
}
