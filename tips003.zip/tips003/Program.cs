﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tips003
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Optimización if con k-maps

            // Programa que indica si una persona puede comprar un auto basado en las siguientes reglas
            // Es mayor de edad, tiene el dinero y tiene fiador
            // No es mayor de edad, tiene el dinero y tiene fiador
            // Es mayor de edad, no tiene el dinero pero tiene fiador
            // No es mayor de edad, tiene el dinero y no tiene fiador

            // Variables
            int edad = 20;
            int dinero = 50000;
            bool fiador = false;

            // Colocamos el if de forma tradicional
            Console.WriteLine("---if tradicional---");

            if ((edad >= 18 && dinero >= 35000 && fiador == true) ||
                (edad < 18 && dinero >= 35000 && fiador == true) ||
                (edad >= 18 && dinero < 35000 && fiador == true) ||
                (edad < 18 && dinero >= 35000 && fiador == false))
            {
                Console.WriteLine("Lo puede comprar");
            }
            else 
            {
                Console.WriteLine("No lo puede comprar");
            }

            // Colocamos el if optimizado
            Console.WriteLine("\n---if optimizado---");
            if ((edad < 18 && dinero >= 35000) || (edad >= 18 && fiador ==true))
            {
                Console.WriteLine("Lo puede comprar");
            }
            else
            {
                Console.WriteLine("No lo puede comprar");
            }

        }
    }
}
