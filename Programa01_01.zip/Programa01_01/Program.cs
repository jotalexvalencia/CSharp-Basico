﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa01_01
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Creamos instancia
            CCalculadora calc1 = new CCalculadora(); // = operador de asignación

            // Accedemos a los atributos
            calc1.a = 5; // operador . de pertenencia
            calc1.b = 3;

            // Métodos
            calc1.Muestra();
            calc1.Suma();
            calc1.Muestra();

            Console.WriteLine("----------");
            // Creamos otro objeto
            CCalculadora miCalcu = new CCalculadora();
            miCalcu.a = 18;
            miCalcu.b = 53;
            miCalcu.Suma();

            // Comprobamos que cada objeto tiene su propia información
            calc1.Muestra();
            miCalcu.Muestra();

        }
    }
}
