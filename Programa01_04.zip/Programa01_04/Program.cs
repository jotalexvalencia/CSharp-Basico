﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Programa01_04
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Creamos instancia
            CCalculadora calc1 = new CCalculadora();

            // Accedemos a los atributos para colocar información
            calc1.a = 5;
            calc1.b = 3;

            // Intentamos invocar el método privado
            // No se puede
            // calc1.Muestra();

            // Invocamos método
            calc1.Suma();
        }
    }
}
